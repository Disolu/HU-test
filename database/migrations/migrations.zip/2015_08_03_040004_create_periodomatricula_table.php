<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePeriodomatriculaTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('periodomatricula', function (Blueprint $table) {
            $table->increments('idperiodomatricula');
            $table->string('nombre');            
            $table->datetime('inicio');
            $table->datetime('fin');

            $table->integer('idsede')->unsigned();
            $table->integer('idnivel')->unsigned();
            $table->foreign('idnivel')->references('idnivel')->on('nivel')->onUpdate('cascade');            
            $table->foreign('idsede')->references('idsede')->on('sede')->onUpdate('cascade');            

            $table->integer('usercreate')->unsigned();
            $table->foreign('usercreate')->references('id')->on('users')->onUpdate('cascade');

            $table->integer('userupdate')->unsigned();
            $table->foreign('userupdate')->references('id')->on('users')->onUpdate('cascade');

            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('periodomatricula');
    }
}
